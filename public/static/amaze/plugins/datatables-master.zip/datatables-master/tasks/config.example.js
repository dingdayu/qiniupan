'use strict';

module.exports = {
  md: {
    src: '',
    data: {
      pluginTitle: '',
      pluginDesc: '',
      buttons: '',
      head: ''
    },
    rename: '',
    dist: ''
  }
};
