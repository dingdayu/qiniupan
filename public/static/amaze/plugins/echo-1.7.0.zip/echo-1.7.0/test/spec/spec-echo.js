describe('echo.js', function () {

  describe('init', function () {
    it('should be defined', function () {
      expect(!!echo).toBe(true);
    });
  });

});
